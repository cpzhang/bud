#define _WIN32_WINDOWS	0x0501

#include "windows.h"
#include "Base.h"
#pragma comment(lib, MAKE_DLL_LIB_NAME(Base))
#include "re.h"
using namespace rkt;