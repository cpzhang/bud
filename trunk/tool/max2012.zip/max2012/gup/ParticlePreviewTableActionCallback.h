/********************************************************************
**	file: 		ParticlePreviewTableActionCallback.h
**	author:		cpzhang <chengpengzhang@gmail.com>
**	created:	2011-4-27
**	purpose:	
*********************************************************************/
#ifndef __ParticlePreviewTableActionCallback_h__
#define __ParticlePreviewTableActionCallback_h__

#include "MaxGUPCommon.h"

class ParticlePreviewTableActionCallback : public ActionCallback
{
public:
	BOOL ExecuteAction(int id)
	{
		return FALSE;
	}
};


#endif // __ParticlePreviewTableActionCallback_h__
