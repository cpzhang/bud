/********************************************************************
**	file: 		MaxMaterial.h
**	author:		cpzhang <chengpengzhang@gmail.com>
**	created:	2011-4-15
**	purpose:	
*********************************************************************/
#ifndef __IMaxMaterial_h__
#define __IMaxMaterial_h__
#include "maxtypes.h"

#define MaxMaterial_CLASS_ID	Class_ID(0x3ee95064, 0x66af6d0b)

class IMaxMaterial : public MultiMtl
{
};


#endif // __IMaxMaterial_h__
