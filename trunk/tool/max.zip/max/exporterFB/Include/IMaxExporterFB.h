/********************************************************************
**	file: 		IMaxExporter.h
**	author:		cpzhang <chengpengzhang@gmail.com>
**	created:	2011-5-4
**	purpose:	
*********************************************************************/
#ifndef __IMaxExporter_h__
#define __IMaxExporter_h__

static const Class_ID tMaxExporterFBCID = Class_ID(0x572834ad, 0x4d612e6d);

#define SCENE_EXPORT_VERTEX_COLOR (1<<1)

#endif // __IMaxExporter_h__
